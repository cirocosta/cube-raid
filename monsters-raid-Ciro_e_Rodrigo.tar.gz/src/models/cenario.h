#ifndef CENARIO_H
#define CENARIO_H
#include "../lib/queue.h"

/**
 * Consome um mapa passado como argumento.
 * @param map mapa a ser consumido
 */
void CENARIO_consume_map(Queue map);
#endif
